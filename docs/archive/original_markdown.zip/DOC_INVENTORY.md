# Documentation inventory and change manifest

Inventory taken before edits on 3 October 2026. **43 original `.md` files, zero standalone `.mmd` files**; four inline Mermaid blocks were found. Recursive filesystem enumeration included hidden/ignored files and the generated pytest note, excluding `.git` internals. Dates below are filesystem modification timestamps with local UTC offset, not evidence dates or Git commit dates.

“Current” can mean a valid narrow artifact/source reference, not deployment readiness. “Superseded” means replaced as project guidance, not invalidated numerical evidence. No standalone duplicate files were found; duplicated architecture/result explanations were consolidated in the overview. [Machine-readable manifest](docs/documentation_manifest.json) preserves original hashes and destinations.

## Original inventory

| Original path | One-line purpose | Last modified (before edits) | Classification | Current path |
|---|---|---|---|---|
| `.pytest_cache/README.md` | Generated pytest cache instructions; not project documentation | 2026-10-03T13:57:48+05:30 | current (generated cache; excluded from project guidance) | [.pytest_cache/README.md](.pytest_cache/README.md) |
| `ARCHITECTURE.md` | Original six-hour Beijing forecast architecture, export and compile evidence | 2026-09-10T11:08:35+05:30 | superseded | [docs/archive/ARCHITECTURE.md](docs/archive/ARCHITECTURE.md) |
| `INVENTION_NOTES.md` | Evidence-only technical distinctions and prior-art/IP research needs | 2026-10-03T13:58:58+05:30 | current | [INVENTION_NOTES.md](INVENTION_NOTES.md) |
| `README.md` | Former project entry point for the six-hour forecast release contract | 2026-10-01T23:48:45+05:30 | superseded | [docs/archive/ROOT_README.md](docs/archive/ROOT_README.md) |
| `data/field_sources/README.md` | NWIC rainfall acquisition, wet-only coverage and matching limitations | 2026-09-29T17:10:06+05:30 | current | [data/field_sources/README.md](data/field_sources/README.md) |
| `data/himachal_weather_audit/MODEL_DIAGNOSTIC.md` | Unsupported missing-PM forecast stress test on supplied Himachal data | 2026-09-11T17:23:50+05:30 | current reference; historical protocol | [data/himachal_weather_audit/MODEL_DIAGNOSTIC.md](data/himachal_weather_audit/MODEL_DIAGNOSTIC.md) |
| `data/himachal_weather_audit/README.md` | Four supplied NWIC weather-file counts, overlap and unresolved QC | 2026-09-11T17:16:07+05:30 | current | [data/himachal_weather_audit/README.md](data/himachal_weather_audit/README.md) |
| `data/imd_north_access/IMD_DATA_REQUEST.md` | Unsent IMD historical-data request with variables and access questions | 2026-09-11T14:47:09+05:30 | current | [data/imd_north_access/IMD_DATA_REQUEST.md](data/imd_north_access/IMD_DATA_REQUEST.md) |
| `data/imd_north_access/README.md` | IMD catalogue/API access receipts; no acquired observations | 2026-09-11T14:47:09+05:30 | current reference; historical protocol | [data/imd_north_access/README.md](data/imd_north_access/README.md) |
| `data/india_cpcb_research/README.md` | Restricted CPCB-derived temporal research data and explicit assumptions | 2026-09-10T11:07:49+05:30 | current | [data/india_cpcb_research/README.md](data/india_cpcb_research/README.md) |
| `data/india_delhi_station_samples/README.md` | Delhi 15-minute source audit; unresolved units and timestamps | 2026-10-01T23:30:51+05:30 | current | [data/india_delhi_station_samples/README.md](data/india_delhi_station_samples/README.md) |
| `data/india_delhi_station_samples/SOURCE_VERIFICATION.md` | Evidence for unresolved Delhi pressure units and clock conventions | 2026-10-01T23:30:51+05:30 | current | [data/india_delhi_station_samples/SOURCE_VERIFICATION.md](data/india_delhi_station_samples/SOURCE_VERIFICATION.md) |
| `data/india_station_audit/README.md` | Seven CPCB station samples, source rights and channel availability | 2026-09-10T11:08:35+05:30 | current reference; historical protocol | [data/india_station_audit/README.md](data/india_station_audit/README.md) |
| `data/uci_beijing_air_quality/README.md` | Pinned Beijing forecast/event source, units, license and provenance | 2026-09-10T09:25:02+05:30 | current | [data/uci_beijing_air_quality/README.md](data/uci_beijing_air_quality/README.md) |
| `docs/MODEL_INPUTS_AND_OUTPUTS.md` | Earlier forecast/event/heatmap interfaces and sensor-rule definitions | 2026-09-29T17:39:32+05:30 | superseded | [docs/archive/docs/MODEL_INPUTS_AND_OUTPUTS.md](docs/archive/docs/MODEL_INPUTS_AND_OUTPUTS.md) |
| `docs/PROTOTYPE_READINESS.md` | Earlier forecast/event bench and field gates; not current spatial protocol | 2026-10-01T23:48:45+05:30 | superseded | [docs/archive/docs/PROTOTYPE_READINESS.md](docs/archive/docs/PROTOTYPE_READINESS.md) |
| `docs/reference/ML_INFERENCE.md` | Earlier forecast/event inference and planar heatmap reference | 2026-09-28T12:13:17+05:30 | superseded | [docs/archive/docs/reference/ML_INFERENCE.md](docs/archive/docs/reference/ML_INFERENCE.md) |
| `esp32/ml_integration/README.md` | Serial ESP32 forecast/event build, replay, telemetry and field capture | 2026-10-01T15:54:49+05:30 | current | [esp32/ml_integration/README.md](esp32/ml_integration/README.md) |
| `esp32/model_test/README.md` | Isolated forecast model ESP32 compile/upload instructions | 2026-09-11T16:50:05+05:30 | current | [esp32/model_test/README.md](esp32/model_test/README.md) |
| `ml/evaluation/INDIA_RESULTS.md` | Historical restricted Indian temporal transfer/Baddi measurements | 2026-09-11T16:50:05+05:30 | superseded | [docs/archive/ml/evaluation/INDIA_RESULTS.md](docs/archive/ml/evaluation/INDIA_RESULTS.md) |
| `ml/event_classifier/EVENT_RELIABILITY.md` | Why learned sensor-rule matches are not real hazard probabilities | 2026-09-28T12:13:17+05:30 | current | [ml/event_classifier/EVENT_RELIABILITY.md](ml/event_classifier/EVENT_RELIABILITY.md) |
| `ml/event_classifier/README.md` | Event-rule training/export interface and limitations | 2026-09-25T23:29:39+05:30 | current | [ml/event_classifier/README.md](ml/event_classifier/README.md) |
| `ml/models/india_cpcb_5sensor_6h/README.md` | Retained india_cpcb_5sensor_6h model profile, artifact contract and research limitations | 2026-09-10T11:07:49+05:30 | current | [ml/models/india_cpcb_5sensor_6h/README.md](ml/models/india_cpcb_5sensor_6h/README.md) |
| `ml/models/india_cpcb_pm_6h/README.md` | Retained india_cpcb_pm_6h model profile, artifact contract and research limitations | 2026-09-10T11:07:49+05:30 | current | [ml/models/india_cpcb_pm_6h/README.md](ml/models/india_cpcb_pm_6h/README.md) |
| `ml/models/uci_beijing_5sensor_6h/README.md` | Retained uci_beijing_5sensor_6h model profile, artifact contract and research limitations | 2026-09-10T11:07:49+05:30 | current | [ml/models/uci_beijing_5sensor_6h/README.md](ml/models/uci_beijing_5sensor_6h/README.md) |
| `ml/models/uci_beijing_6h/README.md` | Retained uci_beijing_6h model profile, artifact contract and research limitations | 2026-09-10T09:25:03+05:30 | current | [ml/models/uci_beijing_6h/README.md](ml/models/uci_beijing_6h/README.md) |
| `ml/models/uci_beijing_event_rules_6sensor/README.md` | Retained uci_beijing_event_rules_6sensor model profile, artifact contract and research limitations | 2026-09-25T23:36:59+05:30 | current | [ml/models/uci_beijing_event_rules_6sensor/README.md](ml/models/uci_beijing_event_rules_6sensor/README.md) |
| `ml/models/uci_beijing_pm_6h/README.md` | Retained uci_beijing_pm_6h model profile, artifact contract and research limitations | 2026-09-10T11:07:49+05:30 | current | [ml/models/uci_beijing_pm_6h/README.md](ml/models/uci_beijing_pm_6h/README.md) |
| `reports/nwic_pipeline/INDIA_PLAN.md` | Earlier sampled India extension plan and acceptance gates | 2026-10-03T12:45:37+05:30 | superseded | [docs/archive/reports/nwic_pipeline/INDIA_PLAN.md](docs/archive/reports/nwic_pipeline/INDIA_PLAN.md) |
| `reports/nwic_pipeline/INDIA_REPORT.md` | Sampled India spatial results, NWIC quarantine and source coverage | 2026-10-03T13:28:08+05:30 | superseded | [docs/archive/reports/nwic_pipeline/INDIA_REPORT.md](docs/archive/reports/nwic_pipeline/INDIA_REPORT.md) |
| `reports/nwic_pipeline/NODE_COLLECTION_SPEC.md` | Current A/B/C collection, calibration, rotation and scoring protocol | 2026-10-03T14:55:12+05:30 | current | [reports/nwic_pipeline/NODE_COLLECTION_SPEC.md](reports/nwic_pipeline/NODE_COLLECTION_SPEC.md) |
| `reports/nwic_pipeline/patches/README.md` | Historical patch ordering and already-applied warning | 2026-10-03T13:29:32+05:30 | current | [reports/nwic_pipeline/patches/README.md](reports/nwic_pipeline/patches/README.md) |
| `reports/physics_phase/ERA5_DOWNLOAD.md` | Current exact authorized ERA5-Land prerequisites and join caveats | 2026-10-03T14:15:38+05:30 | current | [reports/physics_phase/ERA5_DOWNLOAD.md](reports/physics_phase/ERA5_DOWNLOAD.md) |
| `reports/physics_phase/PLAN.md` | Prior physics implementation plan | 2026-10-03T13:40:14+05:30 | superseded | [docs/archive/reports/physics_phase/PLAN.md](docs/archive/reports/physics_phase/PLAN.md) |
| `reports/physics_phase/REPORT.md` | Earlier 32-neighbor full-hour physics results and band failures | 2026-10-03T14:17:01+05:30 | superseded | [docs/archive/reports/physics_phase/REPORT.md](docs/archive/reports/physics_phase/REPORT.md) |
| `reports/physics_phase/patches/README.md` | Physics patch scopes, application warning and verification receipt | 2026-10-03T14:18:42+05:30 | current | [reports/physics_phase/patches/README.md](reports/physics_phase/patches/README.md) |
| `reports/practicum/RESULTS.md` | Measured 32-neighbor practicum tables/figures with current demo routing | 2026-10-03T15:02:54+05:30 | current reference; historical protocol | [reports/practicum/RESULTS.md](reports/practicum/RESULTS.md) |
| `reports/review/DATASETS_AND_PIPELINE.md` | Original dataset inventory and unified long-form design | 2026-10-03T11:26:15+05:30 | superseded | [docs/archive/reports/review/DATASETS_AND_PIPELINE.md](docs/archive/reports/review/DATASETS_AND_PIPELINE.md) |
| `reports/review/REVIEW.md` | Original focused code/security review and synthetic ensemble evidence | 2026-10-03T11:37:21+05:30 | superseded | [docs/archive/reports/review/REVIEW.md](docs/archive/reports/review/REVIEW.md) |
| `reports/two_node_phase/PLAN.md` | Completed exactly-two-node implementation plan | 2026-10-03T14:41:10+05:30 | superseded | [docs/archive/reports/two_node_phase/PLAN.md](docs/archive/reports/two_node_phase/PLAN.md) |
| `reports/two_node_phase/REPORT.md` | Latest uncapped K=2–5 archive scores, losses and corridor eligibility | 2026-10-03T15:09:53+05:30 | current | [reports/two_node_phase/REPORT.md](reports/two_node_phase/REPORT.md) |
| `reports/two_node_phase/examples/README.md` | Synthetic CLI fixtures; no physical weather validation | 2026-10-03T15:06:12+05:30 | current | [reports/two_node_phase/examples/README.md](reports/two_node_phase/examples/README.md) |
| `reports/two_node_phase/patches/README.md` | Two-node patch scopes, already-applied warning and verification receipt | 2026-10-03T15:25:20+05:30 | current | [reports/two_node_phase/patches/README.md](reports/two_node_phase/patches/README.md) |

## Created

- `DOC_INVENTORY.md` (this file).
- `docs/PROJECT_OVERVIEW.md`, `docs/README.md`, `docs/DATA_LICENSES.md`, `docs/DOCUMENTATION_VERIFICATION.md`.
- `docs/archive/README.md`, `docs/documentation_manifest.json`.
- Replacement root `README.md` routing to the single overview; the former README was moved, not discarded.
- `docs/archive/diagrams/ARCHITECTURE__1.mmd`: verbatim extraction from `ARCHITECTURE.md`.
- `docs/archive/diagrams/reports__nwic_pipeline__INDIA_REPORT__1.mmd`: verbatim extraction from `reports/nwic_pipeline/INDIA_REPORT.md`.
- `docs/archive/diagrams/reports__physics_phase__REPORT__1.mmd`: verbatim extraction from `reports/physics_phase/REPORT.md`.
- `docs/archive/diagrams/reports__review__REVIEW__1.mmd`: verbatim extraction from `reports/review/REVIEW.md`.

## Moved original files

- `ARCHITECTURE.md` → `docs/archive/ARCHITECTURE.md`.
- `README.md` → `docs/archive/ROOT_README.md`.
- `docs/MODEL_INPUTS_AND_OUTPUTS.md` → `docs/archive/docs/MODEL_INPUTS_AND_OUTPUTS.md`.
- `docs/PROTOTYPE_READINESS.md` → `docs/archive/docs/PROTOTYPE_READINESS.md`.
- `docs/reference/ML_INFERENCE.md` → `docs/archive/docs/reference/ML_INFERENCE.md`.
- `ml/evaluation/INDIA_RESULTS.md` → `docs/archive/ml/evaluation/INDIA_RESULTS.md`.
- `reports/nwic_pipeline/INDIA_PLAN.md` → `docs/archive/reports/nwic_pipeline/INDIA_PLAN.md`.
- `reports/nwic_pipeline/INDIA_REPORT.md` → `docs/archive/reports/nwic_pipeline/INDIA_REPORT.md`.
- `reports/physics_phase/PLAN.md` → `docs/archive/reports/physics_phase/PLAN.md`.
- `reports/physics_phase/REPORT.md` → `docs/archive/reports/physics_phase/REPORT.md`.
- `reports/review/DATASETS_AND_PIPELINE.md` → `docs/archive/reports/review/DATASETS_AND_PIPELINE.md`.
- `reports/review/REVIEW.md` → `docs/archive/reports/review/REVIEW.md`.
- `reports/two_node_phase/PLAN.md` → `docs/archive/reports/two_node_phase/PLAN.md`.

## Updated original files

- `INVENTION_NOTES.md`.
- `data/himachal_weather_audit/MODEL_DIAGNOSTIC.md`.
- `data/imd_north_access/README.md`.
- `data/india_cpcb_research/README.md`.
- `data/india_station_audit/README.md`.
- `esp32/ml_integration/README.md`.
- `esp32/model_test/README.md`.
- `ml/event_classifier/README.md`.
- `ml/models/india_cpcb_5sensor_6h/README.md`.
- `ml/models/india_cpcb_pm_6h/README.md`.
- `ml/models/uci_beijing_5sensor_6h/README.md`.
- `ml/models/uci_beijing_6h/README.md`.
- `ml/models/uci_beijing_event_rules_6sensor/README.md`.
- `ml/models/uci_beijing_pm_6h/README.md`.
- `reports/physics_phase/patches/README.md`.
- `reports/practicum/RESULTS.md`.

## Unchanged original files

- `.pytest_cache/README.md`.
- `data/field_sources/README.md`.
- `data/himachal_weather_audit/README.md`.
- `data/imd_north_access/IMD_DATA_REQUEST.md`.
- `data/india_delhi_station_samples/README.md`.
- `data/india_delhi_station_samples/SOURCE_VERIFICATION.md`.
- `data/uci_beijing_air_quality/README.md`.
- `ml/event_classifier/EVENT_RELIABILITY.md`.
- `reports/nwic_pipeline/NODE_COLLECTION_SPEC.md`.
- `reports/nwic_pipeline/patches/README.md`.
- `reports/physics_phase/ERA5_DOWNLOAD.md`.
- `reports/two_node_phase/REPORT.md`.
- `reports/two_node_phase/examples/README.md`.
- `reports/two_node_phase/patches/README.md`.

No documentation files were deleted: archived guides retain their bodies and protocol evidence, with archive notices and rebased links. Narrow current references received only scope corrections/link repairs where needed. Data, model artifacts, firmware, tests, raw source receipts, result CSV/JSON, patch snapshots and Python code were left unchanged by consolidation.




## New documentation inventory

Dates are current filesystem timestamps. Original inventory dates above remain frozen.

| Path | One-line purpose | Last modified | Classification |
|---|---|---|---|
| [DOC_INVENTORY.md](DOC_INVENTORY.md) | Complete original/new inventory and created/moved/unchanged manifest | 2026-10-03T16:32:56+05:30 | current |
| [README.md](README.md) | Verbatim original inline Mermaid diagram; historical reference | 2026-10-03T16:22:40+05:30 | current |
| [docs/DATA_LICENSES.md](EVERYTHING.md#source-8ef030a6160f) | Recorded source rights and training-view admission gates | 2026-10-03T16:22:40+05:30 | current |
| [docs/DOCUMENTATION_VERIFICATION.md](EVERYTHING.md#source-bfd8778290ff) | Checks run during consolidation and explicit unverified work | 2026-10-03T16:31:03+05:30 | current |
| [docs/PROJECT_OVERVIEW.md](EVERYTHING.md#source-f795de9ca89c) | Single current project guide and reconciled evidence | 2026-10-03T16:32:17+05:30 | current |
| [docs/README.md](EVERYTHING.md#source-0b5ca119d2be) | Short index of main guide, retained references and archive | 2026-10-03T16:22:40+05:30 | current |
| [docs/archive/README.md](docs/archive/README.md) | Archive scope and original-path mapping instructions | 2026-10-03T16:22:40+05:30 | current |
| [docs/archive/diagrams/ARCHITECTURE__1.mmd](docs/archive/diagrams/ARCHITECTURE__1.mmd) | Verbatim original inline Mermaid diagram; historical reference | 2026-10-03T16:22:40+05:30 | superseded; archived original diagram |
| [docs/archive/diagrams/reports__nwic_pipeline__INDIA_REPORT__1.mmd](docs/archive/diagrams/reports__nwic_pipeline__INDIA_REPORT__1.mmd) | Verbatim original inline Mermaid diagram; historical reference | 2026-10-03T16:22:40+05:30 | superseded; archived original diagram |
| [docs/archive/diagrams/reports__physics_phase__REPORT__1.mmd](docs/archive/diagrams/reports__physics_phase__REPORT__1.mmd) | Verbatim original inline Mermaid diagram; historical reference | 2026-10-03T16:22:40+05:30 | superseded; archived original diagram |
| [docs/archive/diagrams/reports__review__REVIEW__1.mmd](docs/archive/diagrams/reports__review__REVIEW__1.mmd) | Verbatim original inline Mermaid diagram; historical reference | 2026-10-03T16:22:40+05:30 | superseded; archived original diagram |

## India sensor research update — 5 October 2026

The original inventory snapshot above remains historical evidence. No documentation was moved or deleted in this phase. Current additions/updates are listed below; the new audit/commands/reports are references linked from the single main overview. Existing invention/license/archive documents remain unchanged.

| Path | Current purpose | Last modified (Asia/Kolkata) | Status |
|---|---|---|---|
| [docs/INDIA_SENSOR_RISK_PLAN.md](EVERYTHING.md#source-895004202eb0) | India sensor audit, capability matrix, source rights and incremental plan | 2026-10-05T19:57:23+05:30 | current; reference or main guide as stated |
| [ml/india_sensor/README.md](ml/india_sensor/README.md) | Sensor-only feature/label contract and exact prepare/train/calibrate/demo commands | 2026-10-05T19:48:49+05:30 | current; reference or main guide as stated |
| [reports/india_sensor_phase/REPORT.md](reports/india_sensor_phase/REPORT.md) | Executed India research phase, measured results, losses and pending evidence | 2026-10-05T19:55:48+05:30 | current; reference or main guide as stated |
| [reports/india_sensor_phase/RESULTS.md](reports/india_sensor_phase/RESULTS.md) | Frozen A-D/baseline tables and station-bootstrap Brier intervals | 2026-10-05T19:49:49+05:30 | current; reference or main guide as stated |
| [reports/india_sensor_phase/patches/README.md](reports/india_sensor_phase/patches/README.md) | Ordered already-applied review patches and evidence exclusions | 2026-10-05T19:55:48+05:30 | current; reference or main guide as stated |
| [docs/PROJECT_OVERVIEW.md](EVERYTHING.md#source-f795de9ca89c) | Main guide: India research supplement and user-specified hardware, spatial results unchanged | 2026-10-05T19:53:36+05:30 | current; reference or main guide as stated |
| [docs/README.md](EVERYTHING.md#source-0b5ca119d2be) | Main guide and updated reference index | 2026-10-05T19:53:36+05:30 | current; reference or main guide as stated |
| [reports/nwic_pipeline/NODE_COLLECTION_SPEC.md](reports/nwic_pipeline/NODE_COLLECTION_SPEC.md) | Retained A/B/hidden-C protocol, specified parts and encoder/RTC/health requirements | 2026-10-05T19:53:36+05:30 | current; reference or main guide as stated |

## Offline update — 6 October 2026

October 5 reports/patches remain historical evidence; newer offline reports supersede their model-selection, calibration and export status. No files were moved or deleted.

| Path | Purpose | Last modified (Asia/Kolkata) | Status |
|---|---|---|---|
| [reports/offline_phase/PLAN.md](reports/offline_phase/PLAN.md) | Predeclared software/physical/data-access separation | 2026-10-05T23:17:59+05:30 | current |
| [reports/offline_phase/REPORT.md](reports/offline_phase/REPORT.md) | Executed offline results, losses and blockers | 2026-10-06T10:58:53+05:30 | current |
| [reports/offline_phase/RESULTS.md](reports/offline_phase/RESULTS.md) | Frozen four-protocol A–D metrics and support | 2026-10-06T10:42:25+05:30 | current |
| [esp32/india_sensor/README.md](esp32/india_sensor/README.md) | Updated commands, interface or main reference as named | 2026-10-06T10:49:32+05:30 | current |
| [ml/models/india_sensor_v1/README.md](ml/models/india_sensor_v1/README.md) | Updated commands, interface or main reference as named | 2026-10-06T10:49:32+05:30 | current |
| [ml/india_sensor/README.md](ml/india_sensor/README.md) | Updated commands, interface or main reference as named | 2026-10-06T10:49:32+05:30 | current |
| [README.md](README.md) | Updated commands, interface or main reference as named | 2026-10-06T10:49:32+05:30 | current |
| [docs/PROJECT_OVERVIEW.md](EVERYTHING.md#source-f795de9ca89c) | Updated commands, interface or main reference as named | 2026-10-06T10:49:32+05:30 | current |
| [docs/README.md](EVERYTHING.md#source-0b5ca119d2be) | Updated commands, interface or main reference as named | 2026-10-06T10:49:32+05:30 | current |
| [reports/nwic_pipeline/NODE_COLLECTION_SPEC.md](reports/nwic_pipeline/NODE_COLLECTION_SPEC.md) | Updated commands, interface or main reference as named | 2026-10-06T10:54:21+05:30 | current |

## Independent-label/context phase — 6 October 2026

Additive references; frozen earlier evidence was neither overwritten nor moved.

| Path | Purpose | Last modified (Asia/Calcutta) | Status |
|---|---|---|---|
| [docs/hazard_label_audit.md](EVERYTHING.md#source-233befa42eae) | hazard label audit phase reference | 2026-10-06T14:04:14+05:30 | current |
| [ml/hazard_context/README.md](ml/hazard_context/README.md) | README phase reference | 2026-10-06T14:04:14+05:30 | current |
| [reports/hazard_context_phase/PLAN.md](reports/hazard_context_phase/PLAN.md) | PLAN phase reference | 2026-10-06T13:43:49+05:30 | current |
| [reports/hazard_context_phase/REPORT.md](reports/hazard_context_phase/REPORT.md) | REPORT phase reference | 2026-10-06T14:06:07+05:30 | current |
| [reports/hazard_context_phase/ERA5_ACCESS.md](reports/hazard_context_phase/ERA5_ACCESS.md) | ERA5 ACCESS phase reference | 2026-10-06T14:04:14+05:30 | current |

## Six-channel India/Mandi update — 11 October 2026

The original October 3 inventory above remains historical. The active project
overview now covers six channels, Mandi modeled-data numerical testing and
independent Himalayan hazards. Its earlier spatial content is retained at
`docs/SPATIAL_RESEARCH_OVERVIEW.md`; model/data paths were preserved.

New active entry points are `scripts/test_india_mandi.py`, `ml/india_mandi/`,
`configs/model_catalog.json`, `configs/mandi_modeled_forecast_v1.json`,
`ml/models/india_mandi_modeled_6h_v1/`,
`ml/generated/india_mandi_modeled_6h_v1/`, and
`reports/india_mandi_phase/`. `docs/ARCHITECTURE.md` documents actual code.
The comprehensive earlier `scripts/test_models.py` remains a historical audit.
Raw Mandi API/CSV files are local and ignored; manifests/models/results are kept.

Current static review and file counts: `reports/india_mandi_phase/repository_review.json`.
The review distinguishes modeled, secondary observational, synthetic and
independently observed event evidence rather than combining their scores.

## Low-cost source review — 12 October 2026

`docs/reference/FREE_DATA_SOURCE_REVIEW.md` records checked public access
documentation, a concrete OpenAQ Baddi station lead, the unverified Mandi PM
coverage, and the difference between satellite/model context and independent
local event evidence. Linked from `docs/README.md`. No new raw data or model
weights were added in this documentation update.

## Copernicus ten-year acquisition setup — 12 October 2026

`docs/reference/COPERNICUS_MANDI_DOWNLOAD.md` records the 2016–2025 selections,
portal size limit, setup and other access needs. Source-only monthly requests
are in `data/registry/copernicus_mandi_context_requests_v1.json`; the downloader
is `scripts/download_copernicus_mandi.py`. Existing ERA5-Land/physics requests
and model weights are unchanged. Raw data stays ignored. Browser selection and
licence acceptance do not mean a request or download completed.
